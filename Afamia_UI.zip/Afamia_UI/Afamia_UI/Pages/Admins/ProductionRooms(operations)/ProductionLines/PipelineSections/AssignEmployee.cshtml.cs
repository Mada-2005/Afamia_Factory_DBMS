using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Afamia_UI.Pages.Admins.ProductionRooms_operations_.ProductionLines.PipelineSections
{
    public class AssignEmployeeModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
