namespace Afamia_UI.Models.Entities
{
    public class PipelineSection
    {
        public int ID { get; set; }
        public int Pipeline_ID { get; set; }
        public string Name { get; set; }
    }
}
