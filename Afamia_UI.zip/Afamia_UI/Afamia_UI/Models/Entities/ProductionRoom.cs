﻿namespace Afamia_UI.Models.Entities
{
    public class ProductionRoom
    {
        public int Id { get; set; }
        public string Place { get; set; }
    }
}
