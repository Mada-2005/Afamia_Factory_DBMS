namespace Afamia_UI.Models.Entities
{
    public class Products_Type
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public float weight { get; set; }
    }
}
