namespace Afamia_UI.Models.Entities
{
    public class ProductionLine
    {
        public int Id { get; set; }
        public int Room_ID { get; set; }
        public string Name { get; set; }
    }
}
